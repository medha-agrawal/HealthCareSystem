import { DiagnosticCentre } from './diagnostic-centre';

describe('DiagnosticCentre', () => {
  it('should create an instance', () => {
    expect(new DiagnosticCentre()).toBeTruthy();
  });
});
