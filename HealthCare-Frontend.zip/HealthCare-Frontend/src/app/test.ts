import { DiagnosticCentre } from './diagnostic-centre';


export class Test {
    
        centre:DiagnosticCentre=new DiagnosticCentre();
        testId:number;
        testName:string;
    constructor(){}

}
