
export class DiagnosticCentre {
    centreId:number;
    centreName:string;
    centreContactNumber:number;
    centreAddress:string;

    
}
