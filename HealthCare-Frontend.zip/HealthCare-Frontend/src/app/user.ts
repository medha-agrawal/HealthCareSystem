
export class User {
    userId:number;
    userName:string;
    userContactNumber:number;
    userEmail:string;
    userAge:number;
    userGender:string;
}
